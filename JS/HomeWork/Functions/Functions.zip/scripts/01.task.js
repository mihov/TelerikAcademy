﻿
function lastDigit(num)
{
    var last = num % 10;

    switch (last)
    {
        case 0:
            return "zero";
        case 1:
            return "one";
        case 2:
            return "two";
        case 3:
            return "three";
        case 4:
            return "four";
        case 5:
            return "five";
        case 6:
            return "six";
        case 7:
            return "seven";
        case 8:
            return "eight";
        case 9:
            return "nine";
        default:
            return "";
    }
}

jsConsole.write("Last digit of 12345 is " + lastDigit(12345));