﻿//2.1.  Declare five variables choosing for each of them the most appropriate 
//      of the types byte, sbyte, short, ushort, int, uint, long, ulong to represent 
//      the following values: 52130, -115, 4825932, 97, -10000.

using System;

class DeclareFiveVariables
{
    static void Main()
    {
        // Declare variables
        ushort ushortVar = 52130;
        sbyte sbyteVar = -115;
        int intVar = 4825932;
        byte byteVar = 97;
        short shortVar = -10000;
    }
}