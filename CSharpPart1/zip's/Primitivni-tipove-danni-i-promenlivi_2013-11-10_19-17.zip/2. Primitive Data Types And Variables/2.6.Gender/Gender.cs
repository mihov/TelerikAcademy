﻿//2.6. Declare a boolean variable called isFemale and assign an appropriate value corresponding to your gender.
using System;

class Gender
{
    static void Main()
    {
        // Declare boolean variable
        bool isFemale = false;

        // Print the results on the console
        Console.WriteLine("Are you female? "+isFemale);

        //Wait for key press
        Console.ReadKey();
    }
}