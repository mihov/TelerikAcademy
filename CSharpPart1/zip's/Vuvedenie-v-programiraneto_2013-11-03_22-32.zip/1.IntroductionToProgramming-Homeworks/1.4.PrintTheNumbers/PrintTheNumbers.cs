﻿//1.4.  Write a program to print the numbers 1, 101 and 1001.
using System;
class PrintTheNumbers
{
    static void Main()
    {
        Console.Title = "1.4. Print the numbers 1, 101 and 1001";
        Console.WriteLine(1);
        Console.WriteLine(101);
        Console.WriteLine(1001);
        Console.ReadKey();
    }
}