﻿//1.2.  Create, compile and run a “Hello C#” console application.
using System;

class HelloCSharp
{
    static void Main()
    {
        Console.Title = "1.2. Hello C#";
        Console.WriteLine("Hello C#");
        Console.ReadKey();
    }
}
