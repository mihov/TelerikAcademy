﻿//1.11. Describe the difference between C# and .NET Framework.
using System;
class Difference
{
    static void Main()
    {
        Console.WriteLine(@"

11.	Describe the difference between C# and .NET Framework.

    C# is a programming language, .NET is a blanket term that tends 
to cover both the .NET Framework (an application framework library)
and the Common Language Runtime which is the runtime in which .NET 
assemblies are run.");
        Console.ReadKey();
    }
}