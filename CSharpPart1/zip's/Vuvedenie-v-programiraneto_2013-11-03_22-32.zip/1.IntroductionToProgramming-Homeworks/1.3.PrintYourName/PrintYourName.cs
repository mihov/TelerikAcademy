﻿//1.3.	Modify the application to print your name.
using System;
class PrintYourName
{
    static void Main()
    {
        Console.Title = "1.3. Print your name";
        Console.WriteLine("Tancho");
        Console.ReadKey();
    }
}