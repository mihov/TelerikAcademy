﻿/** 01. Describe the strings in C#. What is typical for the string data type? Describe the most important methods of the String class.
 * 
 A string is a sequence of characters stored in a certain address in memory. 
 * Remember the type char? 
 * In the variable of type char we can record only one character. 
 * Where it is necessary to process more than one character then strings come to our aid.
 * 
 * 
 * 
 * * **/


using System;

class DescribeTheStringsInCSharp
{
    static void Main()
    {
    }
}
