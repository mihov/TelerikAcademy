﻿namespace Animals
{
    public interface ISound
    {
        void ProduceSound(); 
    }
}
