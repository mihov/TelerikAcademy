﻿namespace ProblemStudent
{
    public enum Specialty
    {
        BusinessStrategy,
        OrganizationGrowth,
        OrganizationalInnovation,
        FinancialManagement,
        ProgramImplementation,
        ITSecurity
    }
}
