﻿namespace ProblemStudent
{
    public enum University
    {
        UniversityOfTheArts,
        BirkbeckUniversityOf,
        BrunelUniversity,
        CityUniversity,
        UniversityOfEast,
        GoldsmithsUniversity,
        UniversityOfGreenwich,
        ImperialCollegeLondon,
        KingsCollegeLondon,
        KingstonUniversity,
        RoehamptonUniversity,
        UniversityOfWestminster,
        UCL
    }
}
