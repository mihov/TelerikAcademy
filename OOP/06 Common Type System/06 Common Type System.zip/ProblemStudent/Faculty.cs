﻿namespace ProblemStudent
{
    public enum Faculty
    {
        Archaeology,
        Architecture,
        BusinessAdministration,
        Design,
        EarthSciences,
        Economics,
        EnglishStudies,
        FineArts,
        HealthAndSocialWork,
        History,
        Informatics
    }
}
