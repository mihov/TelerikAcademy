﻿namespace MobileWorld
{
    using System;

    class MainProgram
    {
        static void Main()
        {
            GSMTest.Run();
            Console.WriteLine("\n\n\n");
            GSMCallHistoryTest.Run();
        }
    }
}
