﻿namespace Task02
{
    public class Potato
    {
        public bool HasBeenPeeled { get; set; }

        public bool IsFresh { get; set; }
    }
}