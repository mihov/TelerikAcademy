﻿namespace Eatery
{
    public class Carrot : Vegetable
    {
		// Code
    }
}