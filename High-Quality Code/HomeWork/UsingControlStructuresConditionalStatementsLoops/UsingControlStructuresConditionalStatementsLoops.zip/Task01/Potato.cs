﻿namespace Eatery
{
    public class Potato : Vegetable
    {
		// Code;
    }
}