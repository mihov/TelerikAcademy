﻿namespace Eatery
{
    public class Bowl
    {
        public void Add(Vegetable vegetableToAdd)
        {
            // Code
        }
    }
}