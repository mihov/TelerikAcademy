﻿namespace Eatery
{
    public abstract class Vegetable
    {
        public void Cut()
        {
            // Code
        }

        public void Peel()
        {
            // Code
        }
    }
}
